package com.example.sliders;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

/**
 * This is a simple demo using sliders and buttons with anonymous inner classes which
 * implement the used event listeners.
 *
 * Take a close look at the Color library.
 * It will be very useful when you begin working on Lab #2 :)
 */
public class MainActivity extends AppCompatActivity {
    LinearLayout parent;
    TextView raw_score;
    SeekBar seeker;
    Button party_rock;
    int[] colors = {Color.WHITE, Color.LTGRAY, Color.GRAY, Color.BLUE, Color.BLACK, Color.YELLOW, Color.CYAN, Color.GREEN, Color.RED, Color.MAGENTA};


    private void initialize() {
        parent = findViewById(R.id.main);
        raw_score = findViewById(R.id.updater);
        seeker = findViewById(R.id.seek);
        party_rock = findViewById(R.id.randomizer);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        initialize();
        seeker.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @SuppressLint("DefaultLocale")
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                raw_score.setText(String.format("%d", progress));
                parent.setBackgroundColor(colors[progress - 1]);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        party_rock.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Random generator = new Random();
                int index = generator.nextInt(10 - 1) + 1;
                seeker.setProgress(index);
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}