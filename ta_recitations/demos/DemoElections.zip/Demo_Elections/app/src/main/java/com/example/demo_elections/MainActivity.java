package com.example.demo_elections;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Demo_Elections is a simple application that explores:
 * 1) Widgets: Buttons, TextView
 * 2) Event Listeners (OnClick)
 * 3) Android Activity Lifecycle
 * Credit to the Simpsons: https://www.youtube.com/watch?v=EV_c1-YTk8M
 * Last Update: 2025-01-01
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button voteDemocrat;
    Button voteRepublican;
    TextView results;
    int rigged_count;

    public void start() {
        voteDemocrat = findViewById(R.id.vote_democrat);
        voteRepublican = findViewById(R.id.vote_republican);
        results = findViewById(R.id.vote_result);
        rigged_count = 0;
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("votes", rigged_count);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        rigged_count = savedInstanceState.getInt("votes");
        if (rigged_count > 0) {
            results.setText(String.format("You have voted for John McCain %d times.", rigged_count));

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        // Connect Views to the Controller
        start();
        // Initialize the Event Listeners
        voteDemocrat.setOnClickListener(this);
        voteRepublican.setOnClickListener(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.parent_container), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }


    @SuppressLint("DefaultLocale")
    @Override
    public void onClick(View v) {
        if (v == voteDemocrat || v == voteRepublican) {
            rigged_count++;
        }
        results.setText(String.format("You have voted for John McCain %d times.", rigged_count));
    }
}