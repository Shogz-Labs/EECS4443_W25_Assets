package com.example.recyclerviewlol;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ChampionAdapter extends RecyclerView.Adapter<ChampionAdapter.ViewHolder> {

    // Load the data source
    Champion[] champions = {
            new Champion("vayne"),
            new Champion("caitlyn"),
            new Champion("kaisa"),
            new Champion("lucian"),
            new Champion("draven"),
            new Champion("lucian"),
            new Champion("kalista"),
            new Champion("jhin"),
            new Champion("missfortune"),
            new Champion("ashe"),
            new Champion("azir"),
            new Champion("blitzcrank"),
            new Champion("chogath"),
            new Champion("gnar"),
            new Champion("irelia"),
            new Champion("jax"),
            new Champion("reksai"),
            new Champion("zyra"),
            new Champion("xinzhao"),
            new Champion("vi"),
            new Champion("twitch"),
            new Champion("varus")

    };


    // Create new views (invoked by the layout manager)
    @NonNull
    @Override
    public ChampionAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.profile, parent, false);
        return new ViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull ChampionAdapter.ViewHolder holder, int position) {
        holder.tv.setText(champions[position].name);
        Context context = holder.itemView.getContext();
        @SuppressLint("DiscouragedApi") int imageResId = context.getResources().getIdentifier(holder.tv.getText().toString(), "drawable", context.getPackageName());
        holder.avatar.setImageResource(imageResId);
        holder.avatar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                view.setAlpha(0.5f);
            }
        });
    }

    @Override
    public int getItemCount() {
        return champions.length;
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView avatar;
        private final TextView tv;

        public ViewHolder(View view) {
            super(view);
            avatar = (ImageView) view.findViewById(R.id.champion_picture);
            tv = (TextView) view.findViewById(R.id.champion_name);
        }
    }
}
