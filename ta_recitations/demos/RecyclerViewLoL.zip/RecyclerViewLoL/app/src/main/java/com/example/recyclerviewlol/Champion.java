package com.example.recyclerviewlol;

public class Champion {
    String name;
    String[] quotes;
    String[] abilities;


    public Champion(String name) {
        this.name = name;
        this.quotes = new String[4];
        this.abilities = new String[4];
    }
}
