package com.example.demo_gestures;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    /*
    A simple application that explores GestureDetector's SimpleOnGestureListener with ImageView Support.
    We also explore using intents to load an image from the phone's internal storage to the ImageView.
     */
    private GestureDetector gd;
    ToneGenerator tone;
    private TextView dt, fl;
    private ImageView image;
    private int double_taps, flings;
    private final int GET_PICTURE = 100;

    private void initialize() {
        dt = findViewById(R.id.double_taps_label);
        fl = findViewById(R.id.flings_label);
        double_taps = flings = 0;
        image = findViewById(R.id.image);
        gd = new GestureDetector(MainActivity.this, new CustomGestureDetector());
        tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GET_PICTURE && resultCode == RESULT_OK && data != null) {
            image.setImageURI(data.getData());
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        // Initialize Variable(s)
        initialize();
        // Assign onTouchListener to image
        image.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return gd.onTouchEvent(motionEvent);
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    //

    class CustomGestureDetector extends GestureDetector.SimpleOnGestureListener {
        public CustomGestureDetector() {
            super();
        }

        @Override
        public boolean onContextClick(@NonNull MotionEvent e) {
            return super.onContextClick(e);
        }

        @SuppressLint("SetTextI18n")
        @Override
        public boolean onDoubleTap(@NonNull MotionEvent e) {
            image.animate().translationY(-e.getY() * 3).scaleX(3.0f).scaleY(3.0f);
            double_taps += 1;
            dt.setText("Double Taps: " + double_taps);
            return super.onDoubleTap(e);
        }

        @Override
        public boolean onDown(@NonNull MotionEvent e) {
            // return super.onDown(e);
            /*
             * We must set onDown to always return true in order for GestureDetectors to work.
             * This is because all gestures begin with onDown().
             * If you implicitly return false, the OS assumes that you want to ignore the rest of the remaining
             * gesture actions.
             */
            return true;
        }

        @SuppressLint("SetTextI18n")
        @Override
        public boolean onFling(@Nullable MotionEvent e1, @NonNull MotionEvent e2, float velocityX, float velocityY) {
            flings += 1;
            tone.startTone(ToneGenerator.TONE_CDMA_ABBR_ALERT, 1000);
            fl.setText("Flings: " + flings);
            return super.onFling(e1, e2, velocityX, velocityY);
        }

        @Override
        public void onLongPress(@NonNull MotionEvent e) {
            Intent i = new Intent().setType("image/*");
            i.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(i, "Select Image"), GET_PICTURE);
            image.animate().translationY(e.getY() * 3).scaleX(1.0f).scaleY(1.0f);
            super.onLongPress(e);
        }
    }
}