package com.example.arrayadapter;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    SearchView input;
    ListView pokedex;
    String[] pokemon;
    ArrayAdapter loader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input = findViewById(R.id.user_input);
        pokedex = findViewById(R.id.pokedex);
        pokemon = getResources().getStringArray(R.array.pokemon);
        loader = new ArrayAdapter<String>(MainActivity.this, R.layout.textview_template, pokemon) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = view.findViewById(R.id.textview_template);
                if (pokemon[position].length() % 2 != 0) {
                    textView.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.pokeball, 0);
                    textView.setBackgroundColor(Color.parseColor("#d9ead3"));
                }
                return view;
            }
        };
        pokedex.setAdapter(loader);
        input.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                loader.getFilter().filter(s);
                return false;
            }
        });

        pokedex.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this, ((TextView) view).getText().toString() + " has been selected!! :)", Toast.LENGTH_SHORT).show();
            }
        });
    }
}