package com.example.demodrawables;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button load_image, take_photo, share_image;
    private ImageView imageholder;
    Intent action;
    Uri loaded_image;
    Toolbar tools;
    private final int GET_PICTURE = 1;
    private final int TAKE_PICTURE = 2;


    /**
     * Create (load) our action bar from res > menu.xml
     *
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    /**
     * Create an action event "listener" for each item in our action bar
     *
     * @param item: Individual options that are nested in the action var
     * @return _
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // "Listener" for the menu item(s) defined in res > menu
        int selected = item.getItemId();
        if (selected == R.id.action_settings) {
            Toast.makeText(getApplicationContext(), "Settings Activated (Stub)", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "Settings Activated (Stub)", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    private void initialize() {
        load_image = findViewById(R.id.load_button);
        take_photo = findViewById(R.id.photo_button);
        share_image = findViewById(R.id.share_button);
        imageholder = findViewById(R.id.imageholder);
        imageholder.setMinimumHeight(250);
        imageholder.setMinimumHeight(250);
        imageholder.setMaxWidth(250);
        imageholder.setMaxHeight(250);
        action = new Intent();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        // Connect Views to the Controller
        initialize();
        // Set OnClick Listeners
        load_image.setOnClickListener(this);
        take_photo.setOnClickListener(this);
        share_image.setOnClickListener(this);
        share_image.setEnabled(false);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public void onClick(View view) {
        if (view == load_image) {
            share_image.setEnabled(true);
            action.setType("image/*");
            action.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(action, "Select Photo from Gallery"), GET_PICTURE);
        } else if (view == take_photo) {
            share_image.setEnabled(false);
            // Take Photo
            action.setAction(Intent.ACTION_GET_CONTENT);
            action = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(action, TAKE_PICTURE);
        }
        // Share Button
        else {
            action.setAction(Intent.ACTION_SEND);
            action.setType("image/*");
            action.putExtra(Intent.EXTRA_SUBJECT, "Hello World, from LE/ EECS4443");
            action.putExtra(Intent.EXTRA_TEXT, "Sharing an image from Shogz");
            action.putExtra(Intent.EXTRA_STREAM, loaded_image);
            startActivity(Intent.createChooser(action, "Share Image"));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri image = loaded_image = data.getData();
            assert image != null;
            if (requestCode == GET_PICTURE) {
                try {
                    // Read the data from the image resource (Uri image)
                    InputStream imageStream = getContentResolver().openInputStream(image);
                    // Convert the input stream into a bitmap (aka the image but in main memory)
                    Bitmap b = BitmapFactory.decodeStream(imageStream);
                    // Convert the Bitmap into a Drawable Resource
                    Drawable drawable = new BitmapDrawable(getResources(), b);
                    // Set the image in ImageView (Auxiliary Method)
                    imageholder.setImageDrawable(drawable);
                    // Redraw the View to ensure the new image is loaded properly
                    imageholder.invalidate();
                    imageStream.close();
                    imageholder.animate().rotation(360f);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            } else if (requestCode == TAKE_PICTURE) {
                share_image.setEnabled(false);
                Bitmap photo = (Bitmap) Objects.requireNonNull(data.getExtras()).get("data");
                Drawable drawable = new BitmapDrawable(getResources(), photo);
                imageholder.setImageDrawable(drawable);
                imageholder.invalidate();
                ObjectAnimator animation = ObjectAnimator.ofFloat(imageholder, "rotation", 0f, 360f);
                animation.setDuration(2000).setRepeatCount(1);
                animation.setRepeatMode(ValueAnimator.REVERSE);
                animation.start();
            }
        }
    }
}
