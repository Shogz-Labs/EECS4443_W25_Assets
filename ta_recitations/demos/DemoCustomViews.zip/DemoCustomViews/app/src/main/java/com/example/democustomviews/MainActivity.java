package com.example.democustomviews;

import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    CustomButton custom_button;
    int count;
    ToneGenerator tone;

    private void initialize() {
        custom_button = findViewById(R.id.custom_button);
        count = 0;
        tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, ToneGenerator.MAX_VOLUME);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        initialize();
        custom_button.setOnClickListener(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public void onClick(View view) {
        if (view == custom_button) {
            if (count % 2 == 0) {
                custom_button.setCustomBackgroundColour(Color.DKGRAY);
                custom_button.setCustomTextColour(Color.GREEN);
            } else {
                custom_button.setCustomBackgroundColour(Color.BLACK);
                custom_button.setCustomTextColour(Color.WHITE);
            }
            count++;
            tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500);
        }
    }
}