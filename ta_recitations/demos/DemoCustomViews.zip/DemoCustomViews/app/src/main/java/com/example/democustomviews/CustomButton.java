package com.example.democustomviews;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CustomButton extends View {

    // Custom Attributes
    final private Paint panel = new Paint();
    private int BACKGROUND_COLOUR = Color.GREEN;
    final int DEFAULT_WIDTH = 250;
    final int DEFAULT_HEIGHT = 100;
    final int TEXT_SIZE = 50;


    private void initialize() {
        setClickable(true);
        setFocusableInTouchMode(true);
        setFocusable(true);
        // Background Colour
        panel.setColor(BACKGROUND_COLOUR);
        // Text Properties
        panel.setTextSize(TEXT_SIZE);
        panel.setTextAlign(Paint.Align.CENTER);
        panel.setColor(Color.DKGRAY);
    }

    /*
        Overridden on... methods to support our View
     */

    // you can be a bit more creative with how you draw your custom view.... haha :P
    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        setBackgroundColor(BACKGROUND_COLOUR);
        // Get center of view coordinates
        float x = getWidth() / 2f;
        float y = getHeight() / 2f - ((panel.descent() + panel.ascent()) / 2);  // Vertical centering
        // Draw the text at the center
        canvas.drawText("Button", x, y, panel);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    }

    public void setCustomBackgroundColour(int colour) {
        this.BACKGROUND_COLOUR = colour;
        invalidate();
    }

    public void setCustomTextColour(int colour) {
        panel.setColor(colour);
        invalidate();
    }

    /*
        View Constructors which have been overridden to initialize our custom properties
     */

    public CustomButton(Context context) {
        super(context);
        initialize();
    }

    public CustomButton(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }

    public CustomButton(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize();
    }

    public CustomButton(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initialize();
    }
}
