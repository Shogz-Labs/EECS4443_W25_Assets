package com.example.geoquiz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Demo_GeoQuiz is a modified version of the first activity from,
 * "Android Programming The Big Ranch Guide (3rd Edition)"
 * <p>
 * This demo uses multiple activities (intents) and explores toasts and the activity lifecycle
 * (save, restore)
 * <p>
 * We do not use anonymous inner classes to facilitate the event listener (onClick)
 * as we prefer our approach for simplicity.
 */
public class QuizActivity extends AppCompatActivity implements View.OnClickListener {

    // Step 1: Generate Variables for Inflated View Objects
    private Button mTrueButton;
    private Button mFalseButton;
    private Button mNextButton;
    private Button mCheatButton;
    private Button mPrevButton;
    private TextView mQuestionTextView;
    // Application Logic
    private int mCurrentIndex = 0;
    private int question;
    private Question[] mQuestionBank;
    private static final String KEY_INDEX = "index";
    private static final int REQUEST_CODE_CHEAT = 0;
    private boolean mIsCheater;

    private void initialize() {
        mTrueButton = findViewById(R.id.true_button);
        mFalseButton = findViewById(R.id.false_button);
        mNextButton = findViewById(R.id.next_button);
        mCheatButton = findViewById(R.id.cheat_button);
        mPrevButton = findViewById(R.id.prev_button);
        mQuestionTextView = findViewById(R.id.question_text_view);
        mQuestionBank = new Question[]{
                new Question(R.string.question_australia, true),
                new Question(R.string.question_oceans, true),
                new Question(R.string.question_mideast, false),
                new Question(R.string.question_africa, false),
                new Question(R.string.question_americas, true),
                new Question(R.string.question_asia, true)
        };
        question = mQuestionBank[mCurrentIndex].getTextResId();
    }

    private void updateQuestion() {
        question = mQuestionBank[mCurrentIndex].getTextResId();
        mQuestionTextView.setText(question);
    }

    private void checkAnswer(boolean userPressedTrue) {
        boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue();
        int messageResId = 0;

        if (mIsCheater) {
            messageResId = R.string.judgement_toast;
        } else {
            if (userPressedTrue == answerIsTrue) {
                messageResId = R.string.correct_toast;
            } else {
                messageResId = R.string.incorrect_toast;
            }
        }
        Toast.makeText(getApplicationContext(), messageResId, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        // Generate Activity UI
        setContentView(R.layout.activity_main);
        // Step 2: Get References to the Inflated View Objects
        initialize();
        // Step 3: Connect the Listener to the Views
        mTrueButton.setOnClickListener(this);
        mFalseButton.setOnClickListener(this);
        mNextButton.setOnClickListener(this);
        mQuestionTextView.setOnClickListener(this);
        mPrevButton.setOnClickListener(this);
        mCheatButton.setOnClickListener(this);
        // Step 4: Draw Question to the TextView
        updateQuestion();
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_INDEX, mCurrentIndex);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        mCurrentIndex = savedInstanceState.getInt(KEY_INDEX);
        updateQuestion();
    }

    @Override
    public void onClick(View v) {
        if (v == mTrueButton) {
            checkAnswer(true);
        } else if (v == mFalseButton) {
            checkAnswer(false);
        } else if (v == mNextButton || v == mQuestionTextView) {
            mCurrentIndex = (mCurrentIndex + 1) % mQuestionBank.length;
            mIsCheater = false;
            updateQuestion();
        } else if (v == mPrevButton) {
            int new_index = (mCurrentIndex - 1) % mQuestionBank.length;
            if (new_index < 0) {
                Toast.makeText(getApplicationContext(), "We have reached the last question.", Toast.LENGTH_SHORT).show();
            } else {
                mCurrentIndex = new_index;
                updateQuestion();
            }
        } else if (v == mCheatButton) {
            boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue();
            Intent intent = CheatActivity.newIntent(QuizActivity.this, answerIsTrue);
            startActivityForResult(intent, REQUEST_CODE_CHEAT);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }

        if (requestCode == REQUEST_CODE_CHEAT) {
            if (data == null) {
                return;
            }
            mIsCheater = CheatActivity.wasAnswerShown(data);
        }
    }
}