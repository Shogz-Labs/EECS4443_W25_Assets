package com.example.demosensors;

import android.content.Context;
import android.content.res.Resources;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor gyroscope;
    private TextView x, y, z, magnitude, acc;
    private Resources res;

    private void initialize() {
        // Identify the sensors that are supported on your device
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        // Attach Views to the Controller
        x = findViewById(R.id.axis_x);
        y = findViewById(R.id.axis_y);
        z = findViewById(R.id.axis_z);
        res = getResources();
        magnitude = findViewById(R.id.magnitude);
        acc = findViewById(R.id.accuracy);
        // Check for default gyroscope sensor(s)
        if (sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null) {
            Toast.makeText(this, "Gyroscope sensors are supported!", Toast.LENGTH_SHORT).show();
            gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        } else {
            Toast.makeText(this, "No Gyroscope sensor support!", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        // Connect Views to Controller
        initialize();
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    /**
     * Register the sensor to sample for rate of rotation around x-y-z axes.
     */
    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
    }

    /**
     * Unregister sensor to preserve battery when our app is not in use.
     */
    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        /*
        The sensor's coordinate system is the same as the one used for the acceleration sensor.
        Rotation is positive in the counter-clockwise direction;

        Note: Standard gyroscopes provide raw rotational data without any filtering or correction
        for noise and drift (bias).

        In practice, gyroscope noise and drift will introduce errors that need to be compensated for.
        You usually determine the drift (bias) and noise by monitoring other sensors, such as the
        gravity sensor or accelerometer.

        */

        // Retrieve Sensor Data
        float axisX = sensorEvent.values[0];
        float axisY = sensorEvent.values[1];
        float axisZ = sensorEvent.values[2];
        // Perform Actions with Sensor Data
        float omegaMagnitude = (float) Math.sqrt(Math.pow(axisX, 2) + Math.pow(axisY, 2) + Math.pow(axisZ, 2));
        x.setText(String.format(res.getString(R.string.x_axis), axisX));
        y.setText(String.format(res.getString(R.string.y_axis), axisY));
        z.setText(String.format(res.getString(R.string.z_axis), axisZ));
        magnitude.setText(String.format(res.getString(R.string.magnitude), omegaMagnitude));
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
        // DO something here if sensor accuracy changes
        String reps = i >= 2 ? "High" : "Low";
        acc.setText(String.format(res.getString(R.string.accuracy), reps));

    }
}