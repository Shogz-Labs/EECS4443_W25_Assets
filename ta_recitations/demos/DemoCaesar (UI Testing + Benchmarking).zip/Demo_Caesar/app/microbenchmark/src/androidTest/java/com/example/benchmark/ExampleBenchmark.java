package com.example.benchmark;

import android.util.Log;

import androidx.benchmark.junit4.BenchmarkRule;
import androidx.benchmark.BenchmarkState;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Benchmark, which will execute on an Android device.
 * <p>
 * The while loop will measure the contents of the loop, and Studio will
 * output the result. Modify your code to see how it affects performance.
 */

@RunWith(AndroidJUnit4.class)
public class ExampleBenchmark {
    private final Caesar c = new Caesar();
    private String ciphertext, plaintext;
    /**
     * Dear student,
     * Please take the following factors into consideration:
     * 1) Macrobenchmarking is very useful for testing larger use-cases of your application (Start-Up, UI Interactions).
     * 2) Microbenchmarking is useful for testing smaller areas of your code
     * 3) Benchmarking on the emulator introduces errors into the accuracy of your findings. You should benchmark on a physical device.
     * That being said, if you don't have access to a physical android device, you can change the build.gradle of your macrobenchmark to suppress the runtime error:
     * defaultConfig {
     * minSdk 24
     * targetSdk 35
     * // Used to silence errors related to inaccurate metrics from emulator benchmarking....
     * testInstrumentationRunnerArguments["androidx.benchmark.suppressErrors"] = "EMULATOR"
     * //
     * testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
     * }
     * <p>
     * 4) Upon the completion of a benchmark, use Android Studios tools to understand the relevant system traces.
     */
    @Rule
    public BenchmarkRule mBenchmarkRule = new BenchmarkRule();

    @Test
    public void log() {
        final BenchmarkState state = mBenchmarkRule.getState();
        while (state.keepRunning()) {
            Log.d("LogBenchmark", "the cost of writing this log method will be measured");
        }
    }

    @Test
    public void encrypt() {
        final BenchmarkState state = mBenchmarkRule.getState();
        plaintext = "Hello world!";
        while (state.keepRunning()) {
            ciphertext = c.encrypt(plaintext, 3);
        }
    }

    @Test
    public void decrypt(){
        final BenchmarkState state = mBenchmarkRule.getState();
        ciphertext = "URYYB JBEYQ!";
        while (state.keepRunning()){
            plaintext = c.decrypt(ciphertext, 13);
        }
    }
}