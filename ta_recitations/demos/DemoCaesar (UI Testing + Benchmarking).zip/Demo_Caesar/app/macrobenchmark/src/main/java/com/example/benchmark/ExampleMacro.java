package com.example.benchmark;

import androidx.benchmark.macro.CompilationMode;
import androidx.benchmark.macro.FrameTimingMetric;
import androidx.benchmark.macro.StartupMode;
import androidx.benchmark.macro.StartupTimingMetric;
import androidx.benchmark.macro.junit4.MacrobenchmarkRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Arrays;

/**
 * Dear student,
 * Please take the following factors into consideration:
 * 1) Macrobenchmarking is very useful for testing larger use-cases of your application (Start-Up, UI Interactions).
 * 2) Microbenchmarking is useful for testing smaller areas of your code
 * 3) Benchmarking on the emulator introduces errors into the accuracy of your findings. You should benchmark on a physical device.
 * That being said, if you don't have access to a physical android device, you can change the build.gradle of your macrobenchmark to suppress the runtime error:
 * defaultConfig {
 * minSdk 24
 * targetSdk 35
 * // Used to silence errors related to inaccurate metrics from emulator benchmarking....
 * testInstrumentationRunnerArguments["androidx.benchmark.suppressErrors"] = "EMULATOR"
 * //
 * testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
 * }
 * <p>
 * 4) Upon the completion of a benchmark, use Android Studios tools to understand the relevant system traces.
 */

@RunWith(AndroidJUnit4.class)
public class ExampleMacro {

    @Rule
    public MacrobenchmarkRule mBenchmarkRule = new MacrobenchmarkRule();

    @Test
    public void startup() {
        mBenchmarkRule.measureRepeated(
                "com.example.demo_caesar",
                // Put your list of metrics here....
                Arrays.asList(new StartupTimingMetric(), new FrameTimingMetric()),
                CompilationMode.DEFAULT,
                StartupMode.COLD,
                5,
                // Your benchmarking actions go here using UiAutomator to control the device
                scope -> {
                    scope.pressHome();
                    scope.startActivityAndWait();
                    return null;
                });
    }

    /**
     * A benchmark to test ROT-13 on a short piece of plaintext
     */
    @Test
    public void ROT13_Encryption() {
        mBenchmarkRule.measureRepeated(
                "com.example.demo_caesar",
                // Put your list of metrics here....
                Arrays.asList(new StartupTimingMetric(), new FrameTimingMetric()),
                CompilationMode.DEFAULT,
                StartupMode.COLD,
                5,
                // Your benchmarking actions go here using UiAutomator to control the device
                scope -> {
                    UiDevice device = scope.getDevice();
                    // Start the Activity and Wait
                    scope.startActivityAndWait();
                    // Attach Views to Variables (Controllers)
                    UiObject2 spinner, user_input, encrypt, decrypt, button, solution;
                    spinner = device.findObject(By.res(scope.getPackageName(), "spinner_key"));
                    user_input = device.findObject(By.res(scope.getPackageName(), "user_input"));
                    encrypt = device.findObject(By.res(scope.getPackageName(), "encrypt"));
                    decrypt = device.findObject(By.res(scope.getPackageName(), "decrypt"));
                    button = device.findObject(By.res(scope.getPackageName(), "compute_button"));
                    solution = device.findObject(By.res(scope.getPackageName(), "computed_results"));
                    // Perform Actions
                    user_input.setText("Hello world!");
                    encrypt.click();
                    button.click();
                    return null;
                });
    }
}