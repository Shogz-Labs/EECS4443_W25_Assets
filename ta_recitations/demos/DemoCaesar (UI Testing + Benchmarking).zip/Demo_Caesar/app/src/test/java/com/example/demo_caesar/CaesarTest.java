package com.example.demo_caesar;

import junit.framework.TestCase;

/**
 * Recall: You can auto-generate most of the base code by highlighting your class
 * and pressing CTRL + SHIFT + T
 * <p>
 * Simply fill out the remaining data in the dialogue box.
 */
public class CaesarTest extends TestCase {
    Caesar c = new Caesar();

    public void testEncrypt() {
        String plaintext = "Hello world!!!!";
        String expected = "KHOOR ZRUOG!!!!";
        int key = 3;
        assertEquals(c.encrypt(plaintext, key), expected);
    }

    public void testEncrypt_edge() {
        String plaintext = "---XYZ---";
        String expected = "---ABC---";
        int key = 3;
        assertEquals(c.encrypt(plaintext, key), expected);
    }

    public void testDecrypt() {
        String ciphertext = "KHOOR ZRUOG!!!!";
        String expected = "HELLO WORLD!!!!";
        int key = 3;
        assertEquals(expected, c.decrypt(ciphertext, key));
    }

    public void testDecrypt_edge() {
        String ciphertext = "---ABC---";
        String expected = "---XYZ---";
        int key = 3;
        assertEquals(expected, c.decrypt(ciphertext, key));
    }
}