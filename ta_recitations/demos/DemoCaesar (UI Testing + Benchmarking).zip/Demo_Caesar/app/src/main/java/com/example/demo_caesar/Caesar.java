package com.example.demo_caesar;

import java.util.ArrayList;

public class Caesar {
    private final ArrayList<Character> alphabet;

    public Caesar() {
        this.alphabet = new ArrayList<>();
        for (int i = 0; i < 26; i++) {
            alphabet.add((char) (65 + i));
        }
    }

    public String encrypt(String text, int key) {
        StringBuilder solution = new StringBuilder();
        for (Character c : text.toUpperCase().trim().toCharArray()) {
            if (this.alphabet.contains(c)) {
                int shifted_index = (this.alphabet.indexOf(c) + key) % 26;
                if (shifted_index >= 0) {
                    solution.append(this.alphabet.get(shifted_index));
                } else {
                    solution.append(this.alphabet.get(26 + shifted_index));
                }
            } else {
                solution.append(c);
            }
        }
        return solution.toString();
    }

    public String decrypt(String text, int key) {
        return encrypt(text, -key);
    }
}
