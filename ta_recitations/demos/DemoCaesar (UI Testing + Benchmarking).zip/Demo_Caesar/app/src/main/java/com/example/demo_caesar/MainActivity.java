package com.example.demo_caesar;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * A demo application that explores:
 * 1) Caesar Cipher
 * 2) Vertical & Horizontal Layouts
 * 3) onSaveInstanceState, onRestoreInstanceState
 * 4) UI Testing (Espresso, UIAutomator)
 * 5) Benchmarking (Micro, Macro)
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText user_input, results;
    private Spinner key;
    private RadioButton encrypt, decrypt;
    private Button button;
    String solution = "";
    Caesar c;
    private final String SOLUTION_STATE = "STRING_SOLUTION";
    private final String RESULTS_STATE = "RESULTS_VISIBILITY";

    private void initialize() {
        user_input = findViewById(R.id.user_input);
        results = findViewById(R.id.computed_results);
        key = findViewById(R.id.spinner_key);
        encrypt = findViewById(R.id.encrypt);
        decrypt = findViewById(R.id.decrypt);
        button = findViewById(R.id.compute_button);
        c = new Caesar();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        initialize();
        button.setOnClickListener(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public void onClick(View view) {
        if (view == button) {
            if (!encrypt.isChecked() && !decrypt.isChecked()) {
                solution = "Please set a function first. I need to know if you want to encrypt or decrypt; thanks :)";
            } else if (encrypt.isChecked()) {
                solution = c.encrypt(user_input.getText().toString(), Integer.parseInt(key.getSelectedItem().toString()));
            } else if (decrypt.isChecked()) {
                solution = c.decrypt(user_input.getText().toString(), Integer.parseInt(key.getSelectedItem().toString()));
            }
            String label = encrypt.isChecked() ? "Ciphertext" : "Plaintext";
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText(label, solution);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(getApplicationContext(), String.format("%s has been copied to your clipboard!", label), Toast.LENGTH_SHORT).show();
            results.setVisibility(View.VISIBLE);
            results.setText(solution);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(SOLUTION_STATE, solution);
        outState.putInt(RESULTS_STATE, results.getVisibility());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        solution = savedInstanceState.getString(SOLUTION_STATE);
        results.setVisibility(savedInstanceState.getInt(RESULTS_STATE));
        results.setText(solution);
    }
}