package com.example.demo_caesar;


import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;

import android.os.RemoteException;


import androidx.test.espresso.ViewInteraction;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.LargeTest;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.UiDevice;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class MainActivityTest {
    // Declare Views to Interact with
    private final ViewInteraction spinner = onView(withId(R.id.spinner_key));
    private final ViewInteraction user_input = onView(withId(R.id.user_input));
    private final ViewInteraction encrypt = onView(withId(R.id.encrypt));
    private final ViewInteraction decrypt = onView(withId(R.id.decrypt));
    private final ViewInteraction button = onView(withId(R.id.compute_button));
    private final ViewInteraction solution = onView(withId(R.id.computed_results));
    // UiAutomator State
    UiDevice device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());

    @Rule
    public ActivityScenarioRule<MainActivity> mActivityScenarioRule =
            new ActivityScenarioRule<>(MainActivity.class);

    /**
     * A simple test to demonstrate the forwards functionality of ROT-13
     */
    @Test
    public void rot13_simple_encrypt() {
        user_input.perform(typeText("Hello world!"));
        spinner.perform(click());
        onData(allOf(is(instanceOf(String.class)), is("13"))).perform(click());
        encrypt.perform(click());
        button.perform(click());
        solution.check(matches(withText("URYYB JBEYQ!")));
    }

    /**
     * A simple test todemonstrate the backwards functionality of ROT-13
     */
    @Test
    public void rot13_simple_decrypt() {
        user_input.perform(typeText("URYYB JBEYQ!"));
        spinner.perform(click());
        onData(allOf(is(instanceOf(String.class)), is("13"))).perform(click());
        decrypt.perform(click());
        button.perform(click());
        solution.check(matches(withText("HELLO WORLD!")));
    }

    /**
     * A test to demonstrate the effectiveness of onSaveInstanceState() and onRestoreInstanceState()
     *
     * @throws RemoteException
     */
    @Test
    public void switch_orientation_test() throws RemoteException {
        String quote = "Make peace with your mistakes and they'll turn to gold";
        user_input.perform(typeText(quote));
        encrypt.perform(click());
        button.perform(click());
        device.setOrientationLandscape();
        solution.check(matches(withText("PDNH SHDFH ZLWK BRXU PLVWDNHV DQG WKHB'OO WXUQ WR JROG")));
        device.setOrientationNatural();
        solution.check(matches(withText("PDNH SHDFH ZLWK BRXU PLVWDNHV DQG WKHB'OO WXUQ WR JROG")));
    }

    @Test
    public void adversarial_user_test() {
        String quote = "The free soul is rare, but you know it when you see it - basically because you feel good, very good, when you are near or with them.";
        user_input.perform(typeText(quote));
        button.perform(click());
        encrypt.perform(click());
        solution.check(matches(withText("Please set a function first. I need to know if you want to encrypt or decrypt; thanks :)")));
        button.perform(click());
        solution.check(matches(withText("WKH IUHH VRXO LV UDUH, EXW BRX NQRZ LW ZKHQ BRX VHH LW - EDVLFDOOB EHFDXVH BRX IHHO JRRG, YHUB JRRG, ZKHQ BRX DUH QHDU RU ZLWK WKHP.")));
    }
}
