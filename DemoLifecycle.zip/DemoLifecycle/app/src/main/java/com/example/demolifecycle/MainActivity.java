package com.example.demolifecycle;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

/**
 * TA Recitation: Android Activity Lifecycle
 * Contributor(s): Shogo Toyonaga
 * Date: 2024-12-21
 * <p>
 * Abstract: This application was designed to help students understand the Android Activity Lifecycle.
 * In particular, each of the key methods have been overridden to keep track of their changed states.
 * The history of each invoked method is kept in the String ArrayList, states, which is displayed to the user
 * at onResume() through a TextView.
 */

public class MainActivity extends AppCompatActivity {
    private final String TAG = "";
    private ArrayList<String> states;
    private TextView tv;

    public void initialize() {
        states = new ArrayList<>();
        tv = findViewById(R.id.text);
    }

    @SuppressLint("DefaultLocale")
    public String update_text() {
        StringBuilder sol = new StringBuilder();
        for (int i = 0; i < states.size(); i++) {
            sol.append(String.format("Step %d - %s\n", i, states.get(i)));
        }
        return sol.toString();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        initialize();
        states.add("onCreate()");
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        states.add("onRestart()");
    }

    @Override
    protected void onStart() {
        super.onStart();
        states.add("onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        states.add("onResume()");
        // We only want to update our state text here!
        tv.setText(update_text());
    }

    @Override
    protected void onPause() {
        super.onPause();
        states.add("onPause()");
    }

    @Override
    protected void onStop() {
        // Save any permanent data, such as things the user is editing here.
        // Your activity may be killed at any time after this method returns.
        super.onStop();
        states.add("onStop()");
    }

    @Override
    protected void onDestroy() {
        // The Activity record dies here (also, on a system reboot!!)
        super.onDestroy();
        states.add("onDestroy()");
    }

    // Magic Methods!!
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        states.add("onSaveInstanceState()");
        outState.putStringArrayList(TAG, states);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        states = savedInstanceState.getStringArrayList(TAG);
        assert states != null;
        states.add("onRestoreInstanceState()");
    }
}